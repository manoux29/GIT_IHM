/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Asservissement vitesse MCC - communication IHM (PyQt6)
  ******************************************************************************
  * Trame emise (toutes les 100 ms) :
  *   ADC:<u>  Tension:<f>V  Courant:<f>A  tau:<u>  PWM:<u>  Vitesse:<i> RPM\r\n
  *
  * Commandes recues depuis l'IHM (terminees par \n) :
  *   START            -> demarre le moteur (PWM applique)
  *   STOP             -> arrete le moteur (PWM = 0)
  *   DIR:DROITE       -> sens avant
  *   DIR:GAUCHE       -> sens arriere
  *   SPEED:<rpm>      -> consigne de vitesse (0..230 RPM)
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_TIM1_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM4_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
#define IN1_PIN  GPIO_PIN_4   // direction avant
#define IN_PORT  GPIOA
#define PWM_MAX  2099

#define RESOLUTION_ENCODEUR  500
#define RAPPORT_REDUCTION    16
#define VITESSE_MAX_RPM      230   // borne identique a l'IHM (slider 0..230)

uint32_t counter = 0;
uint32_t valeur_brute = 0;
uint32_t valeur_courant_brute = 0;
float tension_volts = 0.0f;
float tension_courant = 0.0f;
float courant = 0.0f;
int16_t  count_precedent = 0;
volatile  int32_t  vitesse_rpm    = 0;
volatile uint8_t flag_1s = 0;
volatile uint8_t flag_100ms = 0;
volatile uint8_t sens = 0;
static int32_t position_precedente=0;
static uint32_t last_index_tick = 0;
static uint32_t tau=0;
static uint32_t temp2=0;
static uint32_t now=0;
uint16_t adc_buffer[2];

int tour;
volatile static int32_t count_actuel;

/* ---- Etat commande pilote par l'IHM ---- */
volatile uint8_t  moteur_on      = 0;    // 0 = STOP, 1 = START
volatile uint16_t consigne_rpm   = 150;  // consigne envoyee par l'IHM (SPEED:)
volatile uint8_t  sens_commande  = 0;    // 0 = DROITE (avant), 1 = GAUCHE (arriere)

/* ---- Reception UART (commandes IHM) ---- */
#define RX_BUF_SIZE  64
uint8_t  rx_byte;                 // octet recu par IT
char     rx_line[RX_BUF_SIZE];    // ligne en cours d'assemblage
volatile uint8_t rx_idx = 0;
volatile uint8_t cmd_ready = 0;   // une ligne complete est prete
char     cmd_buf[RX_BUF_SIZE];    // copie traitee dans la boucle principale

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM1_Init();
  MX_USART2_UART_Init();
  MX_ADC1_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL);

  // Timer 1ms pour les taches periodiques
  HAL_TIM_Base_Start_IT(&htim1);
  HAL_TIM_Base_Start_IT(&htim2);

  // Direction moteur : AVANT (IN1=1)
  HAL_GPIO_WritePin(IN_PORT, IN1_PIN, 1);

  // Demarrer le PWM sur TIM4 Channel 1
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1);

  // Duty cycle initial a 0 : moteur a l'arret tant que l'IHM n'a pas envoye START
  __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, 0);

  HAL_ADC_Start_DMA(&hadc1,(uint32_t*)adc_buffer, 2);

  // Demarrer la reception UART par interruption (1 octet a la fois)
  HAL_UART_Receive_IT(&huart2, &rx_byte, 1);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

    /* ---- Traitement d'une commande recue de l'IHM ---- */
    if(cmd_ready)
    {
      cmd_ready = 0;

      if(strncmp(cmd_buf, "START", 5) == 0)
      {
        moteur_on = 1;
      }
      else if(strncmp(cmd_buf, "STOP", 4) == 0)
      {
        moteur_on = 0;
      }
      else if(strncmp(cmd_buf, "DIR:", 4) == 0)
      {
        if(strncmp(cmd_buf + 4, "GAUCHE", 6) == 0)
          sens_commande = 1;
        else
          sens_commande = 0;          // DROITE par defaut
        moteur_sens(sens_commande);
      }
      else if(strncmp(cmd_buf, "SPEED:", 6) == 0)
      {
        int v = atoi(cmd_buf + 6);
        if(v < 0)               v = 0;
        if(v > VITESSE_MAX_RPM) v = VITESSE_MAX_RPM;
        consigne_rpm = (uint16_t)v;
      }
    }

    if(flag_1s)
    {
      flag_1s = 0;
    }

    if(flag_100ms)
    {
      flag_100ms = 0;

      /* ----- Lecture ADC ----- */
      valeur_brute         = adc_buffer[0];
      valeur_courant_brute = adc_buffer[1];

      tension_volts   = valeur_brute        * 3.3f / 4095.0f;
      tension_courant = valeur_courant_brute * 3.3f / 4095.0f;
      courant = (tension_courant / 0.05f) / 200.0f;  // shunt 0.05 ohm, gain 200

      /* ----- Calcul vitesse encodeur ----- */
      if(vitesse_rpm != 0 && now == 0){
        now = HAL_GetTick();
      }

      int sens_encodeur = __HAL_TIM_IS_TIM_COUNTING_DOWN(&htim3);
      count_actuel = (int32_t)__HAL_TIM_GET_COUNTER(&htim3);
      int32_t delta = count_actuel - count_precedent;

      // correction overflow 16 bits
      if(delta > 32767)  delta -= 65536;
      if(delta < -32768) delta += 65536;
      count_precedent = count_actuel;

      // periode = 100 ms -> *600 pour passer en tr/min
      vitesse_rpm = (delta * 600) / (RESOLUTION_ENCODEUR * 4 * RAPPORT_REDUCTION);
      if(sens_encodeur){
        vitesse_rpm *= -1;
      }

      if(vitesse_rpm >= 218 && temp2 == 0){
        temp2 = HAL_GetTick();
      }
      if(now != 0 && temp2 != 0){
        tau = temp2 - now;
      }

      /* ----- Application de la consigne moteur ----- */
      uint32_t duty;
      if(moteur_on){
        // consigne_rpm (0..230) -> duty (0..PWM_MAX)
        duty = ((uint32_t)consigne_rpm * PWM_MAX) / VITESSE_MAX_RPM;
        if(duty > PWM_MAX) duty = PWM_MAX;
      } else {
        duty = 0;
      }
      __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, duty);

      /* ----- Emission trame vers l'IHM ----- */
      char msg[120];
      int t_ent = (int)tension_volts;
      int t_dec = (int)((tension_volts - t_ent) * 100);
      int c_ent = (int)courant;
      int c_dec = (int)((courant - c_ent) * 100);
      if(c_dec < 0) c_dec = -c_dec;

      sprintf(msg,
              "ADC:%u  Tension:%d.%02dV  Courant:%d.%02dA  tau:%u  PWM:%lu  Vitesse:%ld RPM\r\n",
              (unsigned int)valeur_brute,
              t_ent, t_dec,
              c_ent, c_dec,
              (unsigned int)tau,
              (unsigned long)duty,
              (long)vitesse_rpm);

      HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
    }
  /* USER CODE END 3 */
  }
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  */
static void MX_ADC1_Init(void)
{
  ADC_ChannelConfTypeDef sConfig = {0};

  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = ENABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 2;
  hadc1.Init.DMAContinuousRequests = ENABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = 2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM1 Initialization Function (base 1 ms)
  */
static void MX_TIM1_Init(void)
{
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 8399;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 9;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM2 Initialization Function (base 1 ms)
  */
static void MX_TIM2_Init(void)
{
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 8399;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 9;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM3 Initialization Function (encodeur)
  */
static void MX_TIM3_Init(void)
{
  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 0;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI12;
  sConfig.IC1Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 0;
  sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 0;
  if (HAL_TIM_Encoder_Init(&htim3, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM4 Initialization Function (PWM)
  */
static void MX_TIM4_Init(void)
{
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 0;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 2099;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_TIM_MspPostInit(&htim4);
}

/**
  * @brief USART2 Initialization Function
  */
static void MX_USART2_UART_Init(void)
{
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{
  __HAL_RCC_DMA2_CLK_ENABLE();
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);
}

/**
  * @brief GPIO Initialization Function
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_7, GPIO_PIN_RESET);

  /* PC13 : bouton bleu (inversion sens manuelle) */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /* PA4 PA5 PA7 : sorties (direction / pont en H) */
  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* PA9 : index encodeur */
  GPIO_InitStruct.Pin = GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
}

/* USER CODE BEGIN 4 */
volatile int comp;

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if(htim->Instance == TIM1)
    {
        counter++;
        if(counter >= 1000) // toutes les secondes
        {
            HAL_ADC_Start_DMA(&hadc1,(uint32_t*)adc_buffer, 2);
            flag_1s = 1;
            counter = 0;
        }
    }
    else if(htim->Instance == TIM2)
    {
        comp++;
        if(comp >= 100) // toutes les 100 ms
        {
            flag_100ms = 1;
            comp = 0;
        }
    }
}

void moteur_sens(uint8_t s)
{
    // 0 = avant (IN1=1), 1 = arriere (IN1=0)
    HAL_GPIO_WritePin(IN_PORT, IN1_PIN, (s ? 0 : 1));
}

volatile uint32_t last_press = 0;

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if(GPIO_Pin == GPIO_PIN_13)
    {
        uint32_t now_moteur = HAL_GetTick();
        if((now_moteur - last_press) > 200)
        {
            last_press = now_moteur;
            sens_commande = !sens_commande;
            moteur_sens(sens_commande);
        }
    }
}

/* ---- Reception UART : appele a chaque octet recu ---- */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if(huart->Instance == USART2)
    {
        char c = (char)rx_byte;

        if(c == '\n' || c == '\r')
        {
            if(rx_idx > 0)
            {
                rx_line[rx_idx] = '\0';
                memcpy(cmd_buf, rx_line, rx_idx + 1);
                cmd_ready = 1;
                rx_idx = 0;
            }
        }
        else if(rx_idx < (RX_BUF_SIZE - 1))
        {
            rx_line[rx_idx++] = c;
        }
        else
        {
            rx_idx = 0; // depassement : on repart a zero
        }

        // relancer la reception de l'octet suivant
        HAL_UART_Receive_IT(&huart2, &rx_byte, 1);
    }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  */
void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
}
#endif /* USE_FULL_ASSERT */
